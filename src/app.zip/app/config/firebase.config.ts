export const enviroment={
    production:false,
    firebase:{
        apiKey: "AIzaSyAeYgB5PAPrv3AQ3k0gBRkpWSekCbdyZ4A",
        authDomain: "comprasapp-b37be.firebaseapp.com",
        databaseURL: "https://comprasapp-b37be.firebaseio.com",
        projectId: "comprasapp-b37be",
        storageBucket: "comprasapp-b37be.appspot.com",
        messagingSenderId: "21263855122"

    }
}